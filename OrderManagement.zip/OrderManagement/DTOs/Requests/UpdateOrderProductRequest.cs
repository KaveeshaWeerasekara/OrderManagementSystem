﻿namespace OrderManagement.DTOs.Requests
{
    public class UpdateOrderProductRequest:CreateOrderProductRequest
    {
    }
}
