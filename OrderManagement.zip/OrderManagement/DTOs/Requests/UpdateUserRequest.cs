﻿namespace OrderManagement.DTOs.Requests
{
    public class UpdateUserRequest:CreateUserRequest
    {
    }
}
