﻿namespace OrderManagement.DTOs.Requests
{
    public class UpdateProductRequest:CreateProductRequest
    {
    }
}
